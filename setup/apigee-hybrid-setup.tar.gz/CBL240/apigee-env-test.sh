#!/bin/bash
PROJECT_ID=$GOOGLE_CLOUD_PROJECT
ORG=$GOOGLE_CLOUD_PROJECT
ENV=test
MART_FQDN=${GOOGLE_CLOUD_PROJECT}-mart.hybridtraining.net
INGRESS_FQDN=${GOOGLE_CLOUD_PROJECT}.hybridtraining.net
GCP_REGION=us-central1
GCP_ZONE=us-central1-a

# ---  Validate environment variables - Tick/OK, Cross/Not OK
function statusCheck(){
  if [ -z "$1" ]
  then
    printf "\u274c $2\n"
  else
    printf "\u2714 $2\n"
  fi
}

# Call the function statusCheck to validate the environment
statusCheck "$PROJECT_ID" "PROJECT_ID"
statusCheck "$ORG" "ORG"
statusCheck "$ENV" "ENV"
statusCheck "$MART_FQDN" "MART_FQDN"
statusCheck "$INGRESS_FQDN" "INGRESS_FQDN"
statusCheck "$GCP_REGION" "GCP_REGION"
statusCheck "$GCP_ZONE" "GCP_ZONE"

# Update the compute environment
gcloud config set compute/region $GCP_REGION 
gcloud config set compute/zone  $GCP_ZONE
